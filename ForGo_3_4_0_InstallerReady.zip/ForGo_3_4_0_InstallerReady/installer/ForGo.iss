#define MyAppName "ForGo"
#define MyAppVersion "3.4.0"
#define MyAppPublisher "ForGo"
#define MyAppExeName "ForGo.exe"

[Setup]
AppId={{A28D66D1-E6C2-4B9C-9EC3-3F0A3400ABCD}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\ForGo
DefaultGroupName=ForGo
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
OutputDir=..\release
OutputBaseFilename=ForGo-Setup-3.4.0
SetupIconFile=..\assets\ForGo.ico
UninstallDisplayIcon={app}\ForGo.exe
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
Uninstallable=yes
VersionInfoVersion=3.4.0.0
VersionInfoProductVersion=3.4.0
VersionInfoCompany=ForGo
VersionInfoDescription=ForGo multi-game optimizer installer

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Дополнительно:"; Flags: unchecked

[Files]
Source: "..\dist\ForGo.exe"; DestDir: "{app}"; DestName: "ForGo.exe"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\ForGo"; Filename: "{app}\ForGo.exe"; IconFilename: "{app}\ForGo.exe"; Comment: "ForGo — оптимизатор игр"
Name: "{autodesktop}\ForGo"; Filename: "{app}\ForGo.exe"; IconFilename: "{app}\ForGo.exe"; Tasks: desktopicon; Comment: "ForGo — оптимизатор игр"

[Run]
Filename: "{app}\ForGo.exe"; Description: "Запустить ForGo"; Flags: postinstall nowait skipifsilent
