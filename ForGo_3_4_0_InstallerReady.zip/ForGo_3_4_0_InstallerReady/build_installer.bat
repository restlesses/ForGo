@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ForGo 3.4.0 - Create shareable installer

echo.
echo  ================================================
echo       ForGo 3.4.0 - Создание установщика
echo  ================================================
echo.

if not exist "dist\ForGo.exe" (
  echo [1/3] Файл dist\ForGo.exe не найден. Запускаю сборку приложения...
  echo.
  call "%~dp0build.bat"
  if errorlevel 1 goto :error
)

if not exist "dist\ForGo.exe" (
  echo [ОШИБКА] После сборки не найден dist\ForGo.exe.
  goto :error
)

set "ISCC="
for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"

if not defined ISCC (
  echo [2/3] Компилятор Inno Setup не найден.
  where winget >nul 2>nul
  if errorlevel 1 goto :need_inno
  echo Можно попробовать установить Inno Setup 6 через winget.
  choice /c YN /m "Установить Inno Setup сейчас"
  if errorlevel 2 goto :need_inno
  winget install --id JRSoftware.InnoSetup --exact --accept-source-agreements --accept-package-agreements
  if errorlevel 1 goto :need_inno
  if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
  if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
  if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
  if not defined ISCC goto :need_inno
)

echo [2/3] Компилятор найден:
echo %ISCC%
echo.
if not exist "release" mkdir "release"
echo [3/3] Создаю установщик...
"%ISCC%" "%~dp0installer\ForGo.iss"
if errorlevel 1 goto :error

if not exist "release\ForGo-Setup-3.4.0.exe" (
  echo [ОШИБКА] Компилятор завершился, но установщик не найден.
  goto :error
)

echo.
echo  ГОТОВО!
echo  Установщик для отправки друзьям:
echo  %CD%\release\ForGo-Setup-3.4.0.exe
echo.
echo  Этот файл устанавливает приложение и создаёт ярлыки.
echo  На компьютере друга Python и Inno Setup не нужны.
echo.
pause
exit /b 0

:error
echo.
echo [ОШИБКА] Установщик не создан. Проверь сообщения выше.
echo Если приложение не собралось, сначала исправь build.bat.
echo.
pause
exit /b 1
